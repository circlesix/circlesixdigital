<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'aa7d3319451827');

/** MySQL database username */
define('DB_USER', 'aa7d3319451827');

/** MySQL database password */
define('DB_PASSWORD', 'U#1e6hMOClS');

/** MySQL hostname */
define('DB_HOST', 'aa7d3319451827.db.3319451.hostedresource.com:3311');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '/dN PUAs9Mg%w@?e7u(w|_L*a^3%?n)kSnH_lo%o@yHnn!*zI;+KB/_^?2|kn.3s');
define('SECURE_AUTH_KEY',  'xGdm8:`-R}I[`jq;yPax`uC_:(TAWd.*UZP+!|J;fN`7|,z0d7DWzFD>/[3k%A/1');
define('LOGGED_IN_KEY',    'UJ*[7N+T.CZtkU]sWx>)BiO-)LPRHV*V;Hl6whLDe4& KZaG_aP`7O-;$cQW,dS>');
define('NONCE_KEY',        '0n%Asi=0D?F[@ #&):}c$,;Q)4k8p7vC: <|pI(5+5@*D>$4JqIJg:$b}JJ9WO-G');
define('AUTH_SALT',        '7P/[,&xTRt~N;-HH0}OH={j@& {.wHpi9N6.*mnyC*5?wDws:/b7?%ZOI_l$>t3O');
define('SECURE_AUTH_SALT', ',U#Dt@591},Gr4t?B@]LIG?kY!,9H*B81Qi<3JJy;1dl)tE~RuKVA,!QD>S.r31;');
define('LOGGED_IN_SALT',   'K?@wd0a?jDAB5g|K&:7D[#fmu#7t=,r}TW%HP;N3u$(*)?WPKK=-ugd+2],)xgdG');
define('NONCE_SALT',       'Bn-S$Bg+52E$YNNNGwf-62cWye C^Z^-=gc4yX>RxWvzy{~* ZtS:;ob`IgBMM>/');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
